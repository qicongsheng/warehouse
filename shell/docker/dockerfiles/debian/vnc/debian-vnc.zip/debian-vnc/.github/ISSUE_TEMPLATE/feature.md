---
name: Feature request
about: Open a feature request
---

**Short overview**

**Use case**

**Detailed feature description**

**Additional content**
> Please provide any (mandatory) additional data for your desired feature
