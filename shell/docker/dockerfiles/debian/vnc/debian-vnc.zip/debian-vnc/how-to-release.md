# How to release

* Check if `changelog.md` is correct
* Check if all features are merged in master and pushed
* Pull the latest `nightly` images
* Test if the latest `nightly` build is usable
*  On success - add git branch v{TAG} and tag and push branch
